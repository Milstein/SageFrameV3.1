var TaskToDoLanguage = {
"All":"All",
"Previous":"Previous",
"Today":"Today",
"UpComing":"UpComing",
"Add Task":"Add Task?",
"Add New":"Add New",
"Update":"Update"
};
