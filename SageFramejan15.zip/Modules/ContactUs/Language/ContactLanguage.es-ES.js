var ContactLocal = {
"Contact Us":"Get In Touch",
"All fields are mandatory.":"Todos los campos son obligatorios.",
"Name":"nombre",
"Email":"Correo electrónico",
"Message":"mensaje",
"Submit":"presentar",
"Your Email ID":"Su ID de correo electrónico"
}
