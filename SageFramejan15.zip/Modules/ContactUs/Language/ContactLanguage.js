﻿var ContactLocal = {
    'Contact Us': 'Get In Touch',
    'All fields are mandatory.': 'All fields are mandatory.',
    'Name': 'Name',
    'Email': 'Email',
    'Message': 'Message',
    'Submit': 'Submit',
    'Your Email ID': 'Your Email ID'
}